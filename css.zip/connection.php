<?php
$conn=mysqli_connect("weathernagesh1.db.7623447.44e.hostedresource.net","weathernagesh1","VMMprojects@123","weathernagesh1");
?>