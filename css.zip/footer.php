
<!-- copyright -->
<div class="copyright-agile">
    <p>&copy; 2017 Climate Chronicle. All rights reserved </p>
</div>
<!-- //copyright -->
