<?php
include 'adminheader.php';
?>
<h2 class="text-center">Broadcast Message has been sent Successfully</h2>
<?php
include 'footer.php';
?>