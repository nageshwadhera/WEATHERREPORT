<script>
    for (var i = 65; i <= 90; i++) {
         //alert(String.fromCharCode(i));
    }
</script>

<?php


?>